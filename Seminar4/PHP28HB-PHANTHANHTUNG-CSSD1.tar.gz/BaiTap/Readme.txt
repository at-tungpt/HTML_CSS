Bài 1: 20 điểm
Bài 2: 40 điểm
Bài 3: 40 điểm