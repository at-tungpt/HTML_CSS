Bài 1: 25 điểm
Bài 2: 25 điểm
Bài 3: 50 điểm